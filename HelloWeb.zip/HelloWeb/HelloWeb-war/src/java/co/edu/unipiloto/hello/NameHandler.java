package co.edu.unipiloto.hello;

import java.util.Calendar;

public final class NameHandler {

    private String name;
    private String saludo;
    private int dia, mes, year, edad;
    private Calendar h;
    

    public NameHandler() {
        name = null;
        h = Calendar.getInstance();
    }

    public Calendar getH() {
        return h;
    }

    public void setH(Calendar h) {
        this.h = h;
    }
    
    public String getSaludo(){
            int hora = h.get(Calendar.HOUR_OF_DAY);
            if((hora >= 4)){
                if(hora < 12){
                    saludo = "Buenos días";
                }else if(hora >= 12){
                    if((hora < 18)){
                        saludo = "Buenas tardes";
                    }else{
                        saludo = "Buenas noches";
                    }
                }
            }else{
                saludo = "Buenas noches";
            }
            return saludo;
        }
    
    public void setSaludo(String saludo) {
        this.saludo = saludo;
    }
    
    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    public int getEdad() {
        return edad = 2022 - getYear();
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
/*<c:set var="hora" scope="session" value= "${clock.hora}"/>
        <c:out value="${clock.hora}"/><c:choose>
            <c:when test = "${clock.hora <= 11}" >
                    Buenos dias
                </c:when>
                <c:when test = "${clock.hora >= 12 <= 17}" >
                    Buenas tardes
                </c:when>
                <c:when test = "${clock.hora >= 18 <= 23}">
                    Buenas noches
                </c:when>
                <c:otherwise>
                    Hola
                </c:otherwise>
            </c:choose>*/