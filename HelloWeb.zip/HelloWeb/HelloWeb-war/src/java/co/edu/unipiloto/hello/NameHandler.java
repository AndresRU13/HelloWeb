package co.edu.unipiloto.hello;

import java.util.Calendar;

public final class NameHandler {

    private String name;
    private int tiempo;
    private int dia, mes, year, edad;
    private Calendar h;
    

    public NameHandler() {
        name = null;
        h = Calendar.getInstance();
    }

    public Calendar getH() {
        return h;
    }

    public void setH(Calendar h) {
        this.h = h;
    }
    
    public int getTiempo(){
            int hora = h.get(Calendar.HOUR_OF_DAY);
            if((hora >= 4)){
                if(hora < 12){
                    tiempo = 1;
                }else if(hora >= 12){
                    if((hora < 18)){
                        tiempo = 2;
                    }else{
                        tiempo = 3;
                    }
                }
            }else{
                tiempo = 4;
            }
            return tiempo;
        }
    
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }
    
    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    public int getEdad() {
        return edad = 2022 - getYear();
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}